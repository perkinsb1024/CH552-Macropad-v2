"""Compile and run firmware regressions against host register/USB stubs."""
from pathlib import Path
import subprocess
import tempfile
import sys

ROOT = Path(__file__).resolve().parents[1]
flags = ["cc", "-std=c99", "-Wall", "-Wextra", "-Wno-unknown-pragmas", "-Wno-bitwise-op-parentheses", "-Wno-pointer-to-int-cast", "-D__data=", "-D__idata=", "-D__pdata=", "-D__xdata=", "-D__code=", "-Itests/stubs", "-IwebUploader/upstream/ch55xduino/ch55x/variants/ch552", "-IwebUploader/upstream/ch55xduino/ch55x/cores/ch55xduino"]
if "--no-preview" in sys.argv:
    flags.append("-DENABLE_COLOR_PREVIEW=0")
flags += ["-D" + arg.removeprefix("--define=") for arg in sys.argv[1:]
          if arg.startswith("--define=")]
with tempfile.TemporaryDirectory(prefix="macropad-tests-") as directory:
    suites = [("config", ["src/config.c"]), ("actions", ["src/config.c", "src/actions.c"])]
    suites += [("protocol", ["src/config.c", "src/storage.c", "src/protocol_firmware.c"], variant) for variant in (0, 1)]
    suites += [("usb", [], variant) for variant in (0, 1)]
    suites += [("header_repacking", ["src/config.c", "src/storage.c", "src/protocol_firmware.c"], variant) for variant in (0, 1)]
    suites += [("erase_config", [])]
    suites += [("modified_hold", ["src/config.c", "src/actions.c"], variant) for variant in (0, 1)]
    suites += [("layer_encoding", ["src/config.c", "src/actions.c"], variant) for variant in (0, 1)]
    suites += [("macros", ["src/config.c", "src/actions.c"], variant) for variant in (0, 1)]
    suites += [("timed_actions", ["src/config.c", "src/actions.c"], variant) for variant in (0, 1)]
    suites += [("timed_capacity", ["src/config.c", "src/actions.c"], variant) for variant in (0, 1)]
    suites += [("input", ["src/config.c", "src/actions.c"], variant) for variant in (0, 1)]
    suites += [("sleep_integration", ["src/config.c", "src/actions.c", "src/storage.c", "src/protocol_firmware.c"], variant) for variant in (0, 1)]
    suites += [("live_state", ["src/config.c", "src/actions.c", "src/storage.c", "src/protocol_firmware.c"], variant) for variant in (0, 1)]
    suites += [("per_key_palette", ["src/config.c", "src/actions.c"], variant) for variant in (0, 1)]
    suites += [("alternatives", ["src/config.c", "src/actions.c"], variant) for variant in (0, 1)]
    suites += [("alternative_integration", ["src/config.c", "src/actions.c", "src/storage.c", "src/protocol_firmware.c"], variant) for variant in (0, 1)]
    for suite in suites:
        name, sources, *variant = suite
        options = [f"-DPHYSICAL_VARIANT={variant[0]}"] if variant else []
        binary = str(Path(directory) / (name + str(variant)))
        subprocess.run([*flags, *options, f"tests/{name}_test.c", *sources, "-o", binary], cwd=ROOT, check=True)
        subprocess.run([binary], check=True)
        print(f"Passed {name} {variant}", flush=True)

subprocess.run(["python3", str(ROOT / "tests/build_layout_test.py")], check=True)
subprocess.run(["python3", str(ROOT / "tests/bootloader_test.py")], check=True)
