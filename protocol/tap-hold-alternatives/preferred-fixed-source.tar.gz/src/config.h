#ifndef MACROPAD_CONFIG_H
#define MACROPAD_CONFIG_H

#include <stdint.h>
#include "firmware_types.h"

#define CONFIG_SIZE 128
// Format 18 adds a fifth timer and uses chord scope 7 for globals.
#define CONFIG_VERSION 18
#define CONFIG_MARKER 'B'
#define CONFIG_HEADER_SIZE 9
#define CONFIG_HEADER_MARKER 0
#define CONFIG_HEADER_VERSION 1
#define CONFIG_HEADER_LAYERS 2
#define CONFIG_HEADER_POOL 3
#define CONFIG_HEADER_COUNTS 4
#define CONFIG_HEADER_LED 5
#define CONFIG_HEADER_SLEEP 6
#define CONFIG_HEADER_CRC 7
#define CONFIG_HEADER_VARIANT_MASK 0x01
#define CONFIG_HEADER_LAYER_SHIFT 1
#define CONFIG_HEADER_STARTUP_SHIFT 4
#define CONFIG_HEADER_LAYER_MASK 0x07
#define CONFIG_HEADER_LAYERS_RESERVED 0x80
#define CONFIG_HEADER_POOL_SHIFT 1
#define CONFIG_HEADER_POOL_RESERVED 0x01
#define CONFIG_HEADER_TIMED_MASK 0x07
#define CONFIG_HEADER_CHORD_SHIFT 3
#define CONFIG_HEADER_WINDOW_MASK 0x07
#define CONFIG_HEADER_SLEEP_MASK 0x1F
#define CONFIG_HEADER_SLEEP_RESERVED 0xE0
#define CONFIG_SLEEP_TIMEOUT_MASK 0x03
#define CONFIG_SLEEP_CONSUME 0x04
#define CONFIG_SLEEP_INDICATOR 0x08
#define CONFIG_SLEEP_DIM 0x10
#define CONFIG_SLEEP_DEFAULT 0x0D // 30 minutes, consume wake, show layer indicator.
#ifndef CONFIG_MACRO_REPEAT
#define CONFIG_MACRO_REPEAT 1
#endif
#ifndef CONFIG_MACRO_PAUSE
#define CONFIG_MACRO_PAUSE 1
#endif
#define CONFIG_TIMED_CONSUME 0x40
#define CONFIG_LAYER_PREVIOUS 0xFF
#ifndef CONFIG_TIMED_MAX
#define CONFIG_TIMED_MAX 5
#endif
#ifndef CONFIG_TIMED_ALL_RESET
#define CONFIG_TIMED_ALL_RESET 0
#endif
#define CONFIG_TIMED_INTERVAL_MASK 255
#define CONFIG_TIMED_RESUME 1
#define CONFIG_TIMED_SIZE 6
// Runtime-only built-in timer follows the 128-byte saved image.
#define CONFIG_ACTIVE_SIZE (CONFIG_SIZE + CONFIG_TIMED_SIZE)
#define CONFIG_HEADER_RAINBOW_PHASE_SHIFT 4
#define CONFIG_HEADER_RAINBOW_SPEED_SHIFT 6
#define CONFIG_HEADER_TRANSPARENT_BLACK 0x08
#define CONFIG_PALETTE_VERSION 4
#define CONFIG_PER_KEY_RAINBOW 1
#define CONFIG_MAX_LAYERS (PHYSICAL_VARIANT == CONFIG_THREE_KEYS ? 7 : 5)
#define CONFIG_SIX_KEYS 0
#define CONFIG_THREE_KEYS 1

#ifndef PHYSICAL_VARIANT
#define PHYSICAL_VARIANT CONFIG_SIX_KEYS
#endif
#if PHYSICAL_VARIANT != CONFIG_SIX_KEYS && PHYSICAL_VARIANT != CONFIG_THREE_KEYS
#error "PHYSICAL_VARIANT must be 0 (six keys) or 1 (three keys)."
#endif

// Action numbers are part of the saved format; v18 retains the finalized v16 map.
#define CONFIG_ACTION_NONE             0x0
#define CONFIG_ACTION_PAUSE            0x10 // Full first byte; parameter: 16ms units.
#define CONFIG_ACTION_STRING           0x20 // Full first byte; parameter: pool offset.
#define CONFIG_ACTION_KEY_TAP          0x1
#define CONFIG_ACTION_KEY_HOLD         0x2
#define CONFIG_ACTION_MOUSE_CLICK      0x3 // Auxiliary: click count minus one.
#define CONFIG_ACTION_MOUSE_TOGGLE     0x4
#define CONFIG_ACTION_MOUSE_DOWN       0x14
#define CONFIG_ACTION_MOUSE_UP         0x24
#define CONFIG_ACTION_MOUSE_HOLD       0x34 // Full first byte, not a type.
#define CONFIG_ACTION_SCROLL           0x5
#define CONFIG_ACTION_MOUSE_AXIS       0x6
#define CONFIG_ACTION_MOUSE_XY         0x7
// Consumer types 8-B: bit 0 selects hold; bit 1 selects eight-bit modified usage.
#define CONFIG_ACTION_CONSUMER         0x8
#define CONFIG_ACTION_CONSUMER_HOLD    0x9
#define CONFIG_ACTION_CONSUMER_MODIFIED 0xA
#define CONFIG_ACTION_CONSUMER_MODIFIED_HOLD 0xB
#define CONFIG_ACTION_SET_LAYER        0xC
#define CONFIG_ACTION_MOMENTARY_LAYER  0x2C // Full first byte: layer mode 2.
#define CONFIG_ACTION_RELATIVE_LAYER   0x4C // Full first byte: relative, persistent.
#define CONFIG_ACTION_LED_CONTROL      0xD
#define CONFIG_ACTION_MACRO            0xE
#define CONFIG_ACTION_TAP_HOLD         0xF
#define TAP_FIXED 1
#define CONFIG_ACTION_RESERVED         0xF
#define CONFIG_ACTION_MASK 0xFFFFu
#define CONFIG_LAYER_RELATIVE          0x40
#define CONFIG_LAYER_HOLD              0x20

#define CONFIG_SCROLL_HOLD             0x40
#define CONFIG_SCROLL_HORIZONTAL       0x80
#define CONFIG_SCROLL_MODE_MASK        0x30
#ifndef CONFIG_SCROLL_HOLD_SUPPORT
#define CONFIG_SCROLL_HOLD_SUPPORT 1
#endif
#ifndef CONFIG_SCROLL_ACCELERATION
#define CONFIG_SCROLL_ACCELERATION 0
#endif
#ifndef CONFIG_SCROLL_SLOW_X
#define CONFIG_SCROLL_SLOW_X 1
#endif
#ifndef CONFIG_SCROLL_SLOW_Y
#define CONFIG_SCROLL_SLOW_Y 2
#endif
#ifndef CONFIG_SCROLL_FAST_X
#define CONFIG_SCROLL_FAST_X 1
#endif
#ifndef CONFIG_SCROLL_FAST_Y
#define CONFIG_SCROLL_FAST_Y 1
#endif
#ifndef CONFIG_SCROLL_TIMEOUT_MS
#define CONFIG_SCROLL_TIMEOUT_MS 200
#endif
#if CONFIG_SCROLL_SLOW_X < 1 || CONFIG_SCROLL_SLOW_X > 8 || CONFIG_SCROLL_FAST_X < 1 || CONFIG_SCROLL_FAST_X > 8 || CONFIG_SCROLL_SLOW_Y < 1 || CONFIG_SCROLL_SLOW_Y > 8 || CONFIG_SCROLL_FAST_Y < 1 || CONFIG_SCROLL_FAST_Y > 8
#error Scroll acceleration X/Y presets must be in the range 1-8
#endif
// LED command byte; the auxiliary nibble carries its value.
#define CONFIG_LED_PHASE_SET       0x00
#define CONFIG_LED_PHASE_RELATIVE  0x01
#define CONFIG_LED_SPEED_SET       0x02
#define CONFIG_LED_SPEED_RELATIVE  0x03
#define CONFIG_LED_INDICATOR_SET   0x04
#define CONFIG_LED_INDICATOR_RELATIVE 0x05
#define CONFIG_LED_KEY_SET         0x06
#define CONFIG_LED_KEY_RELATIVE    0x07
#define CONFIG_LED_BOTH_SET        0x08
#define CONFIG_LED_BOTH_RELATIVE   0x09
#define CONFIG_LED_RESTORE         0x0A
#define CONFIG_LED_PRESET_SET      0x0B
#define CONFIG_LED_PRESET_RELATIVE 0x0C
#define CONFIG_LED_PRESET_TOGGLE   0x0D
#define CONFIG_LED_EFFECT_RESTORE  0x80
#define CONFIG_LED_EFFECT_ON       0x81
#define CONFIG_LED_EFFECT_BLINK_1  0x82
#define CONFIG_LED_EFFECT_BLINK_8  0x89
#define CONFIG_LED_EFFECT_DIM      0x10 // OR into effect ON/BLINK commands, never RESTORE.
#define CONFIG_LED_OFF 0
#define CONFIG_LED_DIM 1
#define CONFIG_LED_BRIGHT 2
#define CONFIG_LED_CONFIGURED 15

#define CONFIG_MOUSE_MOVE_HOLD         0x10
#define CONFIG_MOUSE_AXIS_Y            0x20
#define CONFIG_MOUSE_X_NEGATIVE        0x20
#define CONFIG_MOUSE_Y_NEGATIVE        0x40

// Per-layer options: full brightness bit 0, auto-sleep bit 1, indicator bits 2–3, palette bits 4–7.
#define CONFIG_LAYER_OPT_FULL_BRIGHTNESS 0x01
#define CONFIG_LAYER_OPT_AUTO_SLEEP     0x02
#define CONFIG_LAYER_OPT_INDICATOR_SHIFT 2
#define CONFIG_LAYER_OPT_INDICATOR_MASK  0x0C
#define CONFIG_LAYER_OPT_COLOR_SHIFT     4
#define CONFIG_LAYER_OPT_COLOR_MASK      0xF0

#define CONFIG_LAYER_INDICATOR_NONE          0
#define CONFIG_LAYER_INDICATOR_TIMED_ON      1
#define CONFIG_LAYER_INDICATOR_BLINK_BY_LAYER 2
#define CONFIG_LAYER_INDICATOR_ALWAYS_ON     3

#ifdef __SDCC
extern __xdata __at (0x300) uint8_t activeConfig[CONFIG_ACTIVE_SIZE];
#else
extern __xdata uint8_t activeConfig[CONFIG_ACTIVE_SIZE];
#endif
extern __code uint8_t configPalette[16][3];

uint8_t configTimedCount(void);
uint8_t configTimedOffset(void);
uint16_t configCrc(const __xdata uint8_t *image);
FW_BIT configValid(const __xdata uint8_t *image, uint8_t variant);
uint8_t configLayerCount(void);
uint8_t configStartupLayer(void);
#ifdef __SDCC
#define configKeyCount() ((uint8_t)(PHYSICAL_VARIANT == CONFIG_THREE_KEYS ? 3 : 6))
#else
uint8_t configKeyCount(void);
#endif
uint8_t configChordWindowMs(void);
uint8_t configLayerOptions(uint8_t layer);
// Call once per frame with a valid layer, then read packed colors by key.
uint8_t configLedColorOffset(uint8_t layer);
// Offset of this layer's optional palette, or the section end for layerCount.
uint8_t configLayerPaletteOffset(uint8_t layer);
uint8_t configLedColorAt(uint8_t offset, uint8_t key);
void configBinding(uint8_t layer, uint8_t input, __data uint8_t *first, __data uint8_t *second);
FW_BIT configChord(uint8_t layer, uint8_t firstKey, uint8_t secondKey, __data uint8_t *first, __data uint8_t *second);
uint8_t configStringChar(uint8_t offset, uint8_t index);

#endif
