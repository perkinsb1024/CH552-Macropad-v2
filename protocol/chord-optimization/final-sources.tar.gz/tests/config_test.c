#include <assert.h>
#include <stdint.h>
#include <string.h>
#include "../src/config.h"
#include "config_fixture.h"

static void seal(void) {
    uint16_t crc = configCrc(activeConfig);
    activeConfig[CONFIG_HEADER_CRC] = (uint8_t)crc;
    activeConfig[CONFIG_HEADER_CRC + 1] = (uint8_t)(crc >> 8);
}

static void testStarterFixture(uint8_t variant) {
    uint8_t first;
    uint8_t second;
    static const uint8_t usages[6] = {0x29, 0x2C, 0x21, 0x50, 0x52, 0x4F};
    static const uint8_t modifiers[6] = {0, 4, 11, 1, 1, 1};
    static const uint8_t colors[6][3] = {
        {255, 0, 0}, {255, 22, 7}, {255, 16, 0},
        {255, 66, 0}, {255, 124, 0}, {60, 255, 0},
    };
    uint8_t i;
    testLoadStarterProfile(variant);
    assert(configValid(activeConfig, variant));
    // Fixture CRC is checked by configValid; format 6 changes the covered version byte.
    assert(!configValid(activeConfig, variant ^ 1));
    assert(configLayerCount() == 1);
    assert(configStartupLayer() == 0);
    assert(configKeyCount() == (variant ? 3 : 6));
    assert(configChordWindowMs() == 0);
    assert(configLayerOptions(0) == 0x10);
    activeConfig[9 + (variant ? 15 : 22) - 1] |= CONFIG_LAYER_OPT_FULL_BRIGHTNESS;
    seal();
    assert(configValid(activeConfig, variant));
    assert(configLayerOptions(0) & CONFIG_LAYER_OPT_FULL_BRIGHTNESS);
    for (i = 0; i < configKeyCount(); i++) {
        configBinding(0, i, &first, &second);
        assert((first & 15) == CONFIG_ACTION_KEY_TAP);
        assert((first >> 4) == modifiers[i]);
        assert(second == usages[i]);
        assert(configLedColorAt(configLedColorOffset(0), i) == i+1);
        assert(configPalette[i+1][0] == colors[i][0]);
        assert(configPalette[i+1][1] == colors[i][1]);
        assert(configPalette[i+1][2] == colors[i][2]);
    }
    configBinding(0, configKeyCount(), &first, &second);
    assert(first == CONFIG_ACTION_MOUSE_CLICK && second == 4);
    assert(configLedColorAt(configLedColorOffset(0), 0) == 1);
    assert(configLedColorAt(configLedColorOffset(0), 2) == 3);
}

static void testCachedColorOffsets(uint8_t variant) {
    testLoadStarterProfile(variant);
    uint8_t keys = configKeyCount();
    uint8_t layerSize = variant ? 15 : 22;
    testSetLayout(2, 0, 0); // Two layers, starting on layer zero.
    for (uint8_t layer = 0; layer < 2; layer++) {
        uint8_t expected = 9 + layer * layerSize + 2 * (keys + 3);
        uint8_t offset = configLedColorOffset(layer);
        assert(offset == expected);
        // Every nibble value must decode correctly on both sides of a byte.
        for (uint8_t color = 0; color < 16; color++) {
            for (uint8_t key = 0; key < keys; key += 2)
                activeConfig[expected + (key >> 1)] = color | ((15 - color) << 4);
            for (uint8_t key = 0; key < keys; key++)
                assert(configLedColorAt(offset, key) == (key & 1 ? 15 - color : color));
        }
    }
}

static void testInvalid(void) {
    testLoadStarterProfile(CONFIG_SIX_KEYS);
    activeConfig[CONFIG_HEADER_LED] = 0x12;
    seal();
    assert(configValid(activeConfig, CONFIG_SIX_KEYS));
    activeConfig[CONFIG_HEADER_LED] = 2;
    activeConfig[9] = CONFIG_ACTION_KEY_HOLD;
    activeConfig[10] = 0xE0;
    seal();
    assert(!configValid(activeConfig, CONFIG_SIX_KEYS));
    testLoadStarterProfile(CONFIG_SIX_KEYS);
    activeConfig[23] = CONFIG_ACTION_MOUSE_HOLD; // Clockwise rotation
    seal();
    assert(!configValid(activeConfig, CONFIG_SIX_KEYS));
    testLoadStarterProfile(CONFIG_SIX_KEYS);
    activeConfig[31] = 1;
    seal();
    assert(configValid(activeConfig, CONFIG_SIX_KEYS));
    testLoadStarterProfile(CONFIG_SIX_KEYS);
    activeConfig[CONFIG_HEADER_CRC] ^= 1;
    assert(!configValid(activeConfig, CONFIG_SIX_KEYS));
}

static void testHeaderAndIgnoredFields(void) {
    for (uint8_t variant = 0; variant < 2; variant++) {
        testLoadStarterProfile(variant);
        activeConfig[CONFIG_HEADER_LED] |= CONFIG_HEADER_TRANSPARENT_BLACK;
        testSetTimedCount(3);
        activeConfig[CONFIG_HEADER_LED] |= 0xC0;
        activeConfig[127] = 0;
        seal();
        assert(configValid(activeConfig, variant));
        assert(configLayerCount() == 1 && configStartupLayer() == 0);
        assert(configKeyCount() == (variant ? 3 : 6));
        assert(configChordWindowMs() == 0);
        // Header and tail bytes remain covered by CRC.
        activeConfig[127] ^= 1;
        assert(!configValid(activeConfig, variant));
        activeConfig[CONFIG_HEADER_VERSION] = 2;
        seal();
        assert(!configValid(activeConfig, variant));
    }
}

static void testCapacityAndStrings(uint8_t variant) {
    uint8_t size = variant ? 15 : 22;
    uint8_t layers;
    uint8_t pool;
    uint8_t remaining;
    for (layers = 1; layers <= (variant ? 7 : 5); layers++) {
        testLoadStarterProfile(variant);
        testSetLayout(layers, 0, 0);
        pool = 9 + size * layers;
        remaining = CONFIG_SIZE - pool;
        assert(remaining == (variant ? 119 - 15 * layers : 119 - 22 * layers));
        // Extra layers contain canonical empty actions and LED colors.
        testSetStringLength(remaining);
        activeConfig[pool + remaining - 1] = 0;
        seal();
        assert(configValid(activeConfig, variant));
        activeConfig[CONFIG_HEADER_POOL] += 2;
        seal();
        assert(!configValid(activeConfig, variant));
    }
    testLoadStarterProfile(variant);
    pool = 9 + size;
    testSetStringLength(4);
    activeConfig[9] = CONFIG_ACTION_STRING;
    activeConfig[10] = 0;
    activeConfig[pool] = 'A';
    activeConfig[pool + 1] = 0;
    activeConfig[pool + 2] = 'B';
    activeConfig[pool + 3] = 0;
    seal();
    assert(configValid(activeConfig, variant));
    assert(configStringChar(2, 0) == 'B');
    assert(configStringChar(255, 3) == 0); // Must reject an 8-bit address wrap.
    assert(configStringChar(2, 255) == 0);
    activeConfig[10] = 1;
    seal();
    assert(!configValid(activeConfig, variant));
    activeConfig[10] = 2;
    seal();
    assert(configValid(activeConfig, variant));
}

// Exhaust all boundaries in a small pool, including adjacent empty strings.
static void testStringBoundaries(void) {
    for (uint8_t variant = 0; variant < 2; variant++) {
        testLoadStarterProfile(variant);
        uint8_t pool = 9 + (variant ? 15 : 22);
        testSetStringLength(8);
        activeConfig[9] = CONFIG_ACTION_STRING;
        for (uint8_t mask = 0; mask < 128; mask++) {
            for (uint8_t i = 0; i < 7; i++)
                activeConfig[pool + i] = mask & (1 << i) ? 'A' : 0;
            activeConfig[pool + 7] = 0;
            for (uint8_t position = 0; position <= 8; position++) {
                activeConfig[10] = position;
                seal();
                uint8_t expected = position < 8 &&
                    (!position || activeConfig[pool + position - 1] == 0);
                assert(!!configValid(activeConfig, variant) == expected);
            }
        }
    }
}

static void testChords(void) {
    uint8_t first;
    uint8_t second;
    testLoadStarterProfile(CONFIG_THREE_KEYS);
    testSetVariant(1); testSetChordCount(2);
    activeConfig[24] = 0;
    activeConfig[25] = CONFIG_ACTION_KEY_TAP;
    activeConfig[26] = 0x04;
    activeConfig[27] = 2;
    activeConfig[28] = CONFIG_ACTION_KEY_TAP;
    activeConfig[29] = 0x05;
    seal();
    assert(configValid(activeConfig, CONFIG_THREE_KEYS));
    assert(configChord(0, 1, 0, &first, &second));
    assert(first == CONFIG_ACTION_KEY_TAP && second == 0x04);
    assert(!configChord(0, 0, 2, &first, &second));
    activeConfig[27] = 0;
    seal();
    assert(!configValid(activeConfig, CONFIG_THREE_KEYS));
    activeConfig[27] = 3;
    seal();
    assert(!configValid(activeConfig, CONFIG_THREE_KEYS));
}

static void testMouseButtonMasks(void) {
    const uint8_t types[] = {CONFIG_ACTION_MOUSE_CLICK, CONFIG_ACTION_MOUSE_HOLD, CONFIG_ACTION_MOUSE_TOGGLE, CONFIG_ACTION_MOUSE_DOWN, CONFIG_ACTION_MOUSE_UP};
    for (uint8_t variant = 0; variant < 2; variant++) {
        for (uint8_t action = 0; action < sizeof(types); action++) {
            for (uint16_t buttons = 0; buttons < 256; buttons++) {
                testLoadStarterProfile(variant);
                activeConfig[9] = types[action];
                activeConfig[10] = buttons;
                seal();
                assert(configValid(activeConfig, variant) == (buttons >= 1));
            }
        }
    }
}

static void testEveryChordPair(void) {
    // Enumerate the specified lexicographic table independently of the formula.
    for (uint8_t variant = 0; variant < 2; variant++) {
        uint8_t keys = variant ? 3 : 6;
        uint8_t pairs = keys * (keys - 1) / 2;
        for (uint8_t selected = 0; selected < pairs; selected++) {
            testLoadStarterProfile(variant);
            uint8_t offset = configTimedOffset();
            testSetChordCount(1);
            activeConfig[offset] = selected;
            activeConfig[offset + 1] = CONFIG_ACTION_KEY_TAP;
            activeConfig[offset + 2] = 4 + selected;
            seal(); assert(configValid(activeConfig, variant));
            uint8_t index = 0;
            for (uint8_t a = 0; a < keys; a++) {
                for (uint8_t b = a + 1; b < keys; b++, index++) {
                    uint8_t first = 0, second = 0;
                    assert(!!configChord(0, a, b, &first, &second) == (index == selected));
                    if (index == selected) assert(first == CONFIG_ACTION_KEY_TAP && second == 4 + selected);
                    assert(!!configChord(0, b, a, &first, &second) == (index == selected));
                    if (index == selected) assert(first == CONFIG_ACTION_KEY_TAP && second == 4 + selected);
                }
            }
        }
    }
}

static void testPersistentMouseModes(void) {
    for (uint8_t variant = 0; variant < 2; variant++) {
        for (uint8_t aux = 0; aux < 16; aux++) {
            for (uint8_t slot = 0; slot < 6; slot++) {
                testLoadStarterProfile(variant);
                uint8_t offset = 9;
                if (slot == 1) offset = 9 + (variant ? 8 : 14);
                if (slot == 2) {
                    testSetChordCount(1);
                    offset = configTimedOffset() - 2;
                    activeConfig[offset - 1] = 0;
                }
                if (slot == 3 || slot == 4) {
                    testSetTimedCount(1);
                    offset = configTimedOffset() + (slot == 3 ? 1 : 3);
                }
                if (slot == 5) offset = configTimedOffset(); // Unreferenced macro step.
                activeConfig[offset] = (aux << 4) | CONFIG_ACTION_MOUSE_TOGGLE;
                activeConfig[offset + 1] = 0xFF;
                seal(); assert(!!configValid(activeConfig, variant) ==
                    (aux <= 2 || (aux == 3 && (slot == 0 || slot == 2))));
                activeConfig[offset + 1] = 0;
                seal(); assert(!configValid(activeConfig, variant));
                activeConfig[offset] = (aux << 4) | CONFIG_ACTION_CONSUMER_MODIFIED;
                for (unsigned mask = 0; mask < 256; mask++) {
                    activeConfig[offset + 1] = mask;
                    seal(); assert(!!configValid(activeConfig, variant) ==
                        (mask >= 1));
                }
            }
        }
        testLoadStarterProfile(variant);
        activeConfig[CONFIG_HEADER_VERSION] = 12; seal(); assert(!configValid(activeConfig, variant));
    }
}

static void testMultiClick(void) {
    for (uint8_t variant = 0; variant < 2; variant++) {
        uint8_t rotation = 9 + (variant ? 8 : 14);
        for (uint8_t aux = 0; aux < 16; aux++) {
            for (uint8_t buttons = 0; buttons < 9; buttons++) {
                // Key, encoder rotation, chord, expiry and next-input slots.
                for (uint8_t slot = 0; slot < 5; slot++) {
                    testLoadStarterProfile(variant);
                    uint8_t offset = 9;
                    if (slot == 1) offset = rotation;
                    if (slot == 2) {
                        testSetChordCount(1);
                        offset = configTimedOffset() - 2;
                        activeConfig[offset - 1] = 0;
                    }
                    if (slot >= 3) {
                        testSetTimedCount(1);
                        offset = configTimedOffset() + (slot == 3 ? 1 : 3);
                    }
                    activeConfig[offset] = (aux << 4) | CONFIG_ACTION_MOUSE_CLICK;
                    activeConfig[offset + 1] = buttons;
                    seal();
                    assert(configValid(activeConfig, variant) == (buttons >= 1));
                    activeConfig[offset] = (aux << 4) | CONFIG_ACTION_MACRO;
                    seal();
                    assert(!configValid(activeConfig, variant));
                }
            }
        }
    }
}

static void testActions(void) {
    uint8_t type;
    uint8_t param;
    uint8_t aux;
    // Exhaust every flag/parameter combination on keys and wheel rotation.
    for (type = CONFIG_ACTION_MOUSE_AXIS; type <= CONFIG_ACTION_MOUSE_XY; type++) {
        unsigned value;
        for (aux = 0; aux < 16; aux++) {
            for (value = 0; value < 256; value++) {
                uint8_t valid = type == CONFIG_ACTION_MOUSE_AXIS ?
                    value != 0x80 : 1;
                testLoadStarterProfile(CONFIG_SIX_KEYS);
                activeConfig[9] = (aux << 4) | type;
                activeConfig[10] = value;
                seal();
                assert(configValid(activeConfig, CONFIG_SIX_KEYS) == valid);
                activeConfig[9] = activeConfig[10] = 0;
                activeConfig[23] = (aux << 4) | type;
                activeConfig[24] = value;
                seal();
                assert(configValid(activeConfig, CONFIG_SIX_KEYS) == (valid && !(aux & 1)));
            }
        }
    }
    for (type = 0; type < 16; type++) {
        testLoadStarterProfile(CONFIG_SIX_KEYS);
        param = 0;
        if (type == CONFIG_ACTION_KEY_TAP || type == CONFIG_ACTION_KEY_HOLD) {
            param = 0x04;
        } else if (type == CONFIG_ACTION_MOUSE_CLICK ||
                   type == CONFIG_ACTION_MOUSE_TOGGLE || type == CONFIG_ACTION_CONSUMER_MODIFIED) {
            param = 1;
        } else if (type == CONFIG_ACTION_SCROLL ||
                   type == CONFIG_ACTION_MOUSE_AXIS ||
                   type == CONFIG_ACTION_MOUSE_XY) {
            param = 1;
        } else if (type == CONFIG_ACTION_CONSUMER || type == CONFIG_ACTION_CONSUMER_HOLD || type == CONFIG_ACTION_CONSUMER_MODIFIED_HOLD) {
            param = 0xE9;
            activeConfig[9] = 0x08; // Volume up
        } else if (type == CONFIG_ACTION_STRING) {
            testSetStringLength(1);
        }
        if (type == CONFIG_ACTION_LED_CONTROL) { activeConfig[9] = 0; param = CONFIG_LED_PHASE_SET; }
        activeConfig[9] = (activeConfig[9] & 0xF0) | type;
        activeConfig[10] = param;
        seal();
        assert(configValid(activeConfig, CONFIG_SIX_KEYS) == (type != CONFIG_ACTION_MACRO && type != CONFIG_ACTION_RESERVED));
    }
        testLoadStarterProfile(CONFIG_SIX_KEYS);
    activeConfig[23] = CONFIG_ACTION_MOMENTARY_LAYER;
    seal();
    assert(!configValid(activeConfig, CONFIG_SIX_KEYS));
    testLoadStarterProfile(CONFIG_SIX_KEYS);
    activeConfig[9] = CONFIG_ACTION_SCROLL;
    activeConfig[10] = 0x80;
    seal();
    assert(!configValid(activeConfig, CONFIG_SIX_KEYS));
    testLoadStarterProfile(CONFIG_SIX_KEYS);
    activeConfig[9] = CONFIG_ACTION_RELATIVE_LAYER;
    activeConfig[10] = 6;
    seal();
    assert(configValid(activeConfig, CONFIG_SIX_KEYS));
    activeConfig[10] = 0xFA;
    seal();
    assert(configValid(activeConfig, CONFIG_SIX_KEYS));
    activeConfig[10] = 7;
    seal();
    assert(!configValid(activeConfig, CONFIG_SIX_KEYS));
    activeConfig[10] = 0xF9;
    seal();
    assert(!configValid(activeConfig, CONFIG_SIX_KEYS));
    activeConfig[9] = 0x10 | CONFIG_ACTION_RELATIVE_LAYER;
    activeConfig[10] = 0;
    seal();
    assert(configValid(activeConfig, CONFIG_SIX_KEYS));
    activeConfig[9] = 0x30 | CONFIG_ACTION_SET_LAYER;
    activeConfig[23] = CONFIG_ACTION_NONE;
    seal();
    assert(!configValid(activeConfig, CONFIG_SIX_KEYS));
    testLoadStarterProfile(CONFIG_THREE_KEYS);
    activeConfig[22] = 0xF2;
    seal();
    assert(configValid(activeConfig, CONFIG_THREE_KEYS));
}

static void testExpandedLayers(uint8_t variant) {
    uint8_t count = variant ? 7 : 5;
    uint8_t size = variant ? 15 : 22;
    uint8_t first, second;
    uint8_t chord = 9 + size * count;
    for (uint8_t startup = 0; startup < count; startup++) {
        testLoadStarterProfile(variant);
        testSetLayout(count, startup, 0);
        testSetChordCount(2); // Two chords: local then global, on the highest layer.
        activeConfig[chord] = (count - 1) << 4;
        activeConfig[chord + 1] = CONFIG_ACTION_SET_LAYER;
        activeConfig[chord + 2] = count - 1;
        activeConfig[chord + 3] = 0x70;
        activeConfig[chord + 4] = CONFIG_ACTION_SET_LAYER;
        activeConfig[chord + 5] = 0;
        uint8_t base = 9 + size * (count - 1);
        activeConfig[base] = CONFIG_ACTION_MOMENTARY_LAYER;
        activeConfig[base + 1] = count - 1;
        activeConfig[base + size - 1] = 0xA9;
        seal();
        assert(configValid(activeConfig, variant));
        assert(configLayerCount() == count && configStartupLayer() == startup);
        assert(configLayerOptions(count - 1) == 0xA9);
        configBinding(count - 1, 0, &first, &second);
        assert(first == CONFIG_ACTION_MOMENTARY_LAYER && second == count - 1);
        assert(configChord(count - 1, 0, 1, &first, &second));
        assert(second == count - 1); // Local wins over global.
        assert(configChord(0, 0, 1, &first, &second) && second == 0);
        testSetLayout(count, count, 0);
        seal();
        assert(!configValid(activeConfig, variant));
        testSetLayout(count + 1, 0, 0); // One more complete layer exceeds the image capacity.
        seal();
        assert(!configValid(activeConfig, variant));
    }
}

static void testLedPayloads(void) {
    for (uint8_t variant = 0; variant < 2; variant++) {
        testLoadStarterProfile(variant);
        unsigned accepted = 0;
        for (unsigned command = 0; command < 256; command++) {
            for (uint8_t value = 0; value < 16; value++) {
                uint8_t expected;
                if (command == 0 || command == 2) expected = value <= 3 || value == 15;
                else if (command == 4 || command == 6 || command == 8) expected = value <= 2 || value == 15;
                else if (command == 1 || command == 3 || command == 5 || command == 7 || command == 9 || command == 12) expected = value != 0 && value != 8;
                else if (command == 10) expected = 1;
                else if (command == 11) expected = value <= 4;
                else if (command == 13) expected = value >= 1 && value <= 4;
                else if (command == CONFIG_LED_EFFECT_RESTORE) expected = 1;
                else if (command >= CONFIG_LED_EFFECT_ON && command <= CONFIG_LED_EFFECT_BLINK_8) expected = 1;
                else if (command >= (CONFIG_LED_EFFECT_ON | CONFIG_LED_EFFECT_DIM) &&
                         command <= (CONFIG_LED_EFFECT_BLINK_8 | CONFIG_LED_EFFECT_DIM)) expected = 1;
                else expected = 0;
                activeConfig[9] = (value << 4) | CONFIG_ACTION_LED_CONTROL;
                activeConfig[10] = command;
                seal();
                assert(configValid(activeConfig, variant) == expected);
                accepted += expected;
                uint8_t rotation = 9 + 2 * ((variant ? 3 : 6) + 1);
                activeConfig[9] = 0; activeConfig[10] = 0;
                activeConfig[rotation] = (value << 4) | CONFIG_ACTION_LED_CONTROL;
                activeConfig[rotation + 1] = command;
                seal();
                assert(configValid(activeConfig, variant) == expected);
                activeConfig[rotation] = CONFIG_ACTION_SCROLL; activeConfig[rotation + 1] = 1;
            }
        }
        assert(accepted == 435);
    }
}

static void testPreviousLayerSentinel(void) {
    for (uint8_t variant = 0; variant <= 1; variant++) {
        for (uint8_t version = 6; version <= CONFIG_VERSION; version++) {
            testLoadStarterProfile(variant); activeConfig[CONFIG_HEADER_VERSION] = version;
            for (uint8_t aux = 0; aux < 3; aux++) {
                activeConfig[9] = CONFIG_ACTION_SET_LAYER | (aux << 4);
                for (uint16_t target = 0; target < 256; target++) {
                    activeConfig[10] = target; seal();
                    assert(configValid(activeConfig, variant) == (version == CONFIG_VERSION && aux <= 2 &&
                        (target < configLayerCount() || (aux <= 1 && target == CONFIG_LAYER_PREVIOUS))));
                }
            }
            activeConfig[9] = CONFIG_ACTION_MOMENTARY_LAYER;
            activeConfig[10] = CONFIG_LAYER_PREVIOUS; seal();
            assert(!configValid(activeConfig, variant));
        }
    }
}

static void testConsumerHoldEncoding(void) {
    for (uint8_t variant = 0; variant < 2; variant++) {
        uint8_t rotation = 9 + 2 * ((variant ? 3 : 6) + 1);
        const uint8_t consumerTypes[] = {CONFIG_ACTION_CONSUMER, CONFIG_ACTION_CONSUMER_HOLD};
        for (uint8_t index = 0; index < 2; index++) {
            uint8_t type = consumerTypes[index];
            testLoadStarterProfile(variant);
            for (uint16_t usage = 0; usage < 4096; usage++) {
                activeConfig[9] = type | ((usage >> 8) << 4);
                activeConfig[10] = usage;
                seal(); assert(!!configValid(activeConfig, variant) == !!usage);
                activeConfig[9] = activeConfig[10] = 0;
                activeConfig[rotation] = type | ((usage >> 8) << 4);
                activeConfig[rotation + 1] = usage;
                seal(); assert(!!configValid(activeConfig, variant) ==
                    (usage && type == CONFIG_ACTION_CONSUMER));
                activeConfig[rotation] = CONFIG_ACTION_SCROLL;
                activeConfig[rotation + 1] = 1;
            }
        }
        testLoadStarterProfile(variant);
        testSetStringLength(2);
        uint8_t pool = configTimedOffset();
        activeConfig[pool] = 'A'; activeConfig[pool + 1] = 0;
        for (uint8_t aux = 0; aux < 16; aux++) {
            activeConfig[9] = aux << 4; activeConfig[10] = 0;
            seal(); assert(!!configValid(activeConfig, variant) == (aux <= (CONFIG_MACRO_PAUSE ? 2 : 1)));
        }
        testSetLayout(1, 0, 1);
        uint8_t timer = configTimedOffset();
        testSetStringLength(0);
        activeConfig[timer + 1] = CONFIG_ACTION_CONSUMER_HOLD;
        activeConfig[timer + 2] = 0xE9;
        seal(); assert(!configValid(activeConfig, variant));
        // Legacy bytes must never be interpreted using the v8 type allocation.
        testLoadStarterProfile(variant); activeConfig[CONFIG_HEADER_VERSION] = 7;
        activeConfig[9] = 9; activeConfig[10] = 0xE9;
        seal(); assert(!configValid(activeConfig, variant));
    }
}

static void testScrollHoldValidation(void) {
    for (uint8_t variant = 0; variant < 2; variant++) {
        testLoadStarterProfile(variant);
        activeConfig[9] = CONFIG_ACTION_SCROLL | CONFIG_SCROLL_HOLD;
        activeConfig[10] = 1; seal(); assert(configValid(activeConfig, variant));
        activeConfig[10] = 0x80; seal(); assert(!configValid(activeConfig, variant));
        activeConfig[9] = activeConfig[10] = 0;
        uint8_t rotation = 9 + 2 * ((variant ? 3 : 6) + 1);
        activeConfig[rotation] = CONFIG_ACTION_SCROLL | CONFIG_SCROLL_HOLD;
        activeConfig[rotation + 1] = 1;
        seal(); assert(!configValid(activeConfig, variant));
        testLoadStarterProfile(variant); testSetLayout(1, 0, 1);
        uint8_t timer = configTimedOffset();
        activeConfig[timer + 1] = CONFIG_ACTION_SCROLL | CONFIG_SCROLL_HOLD;
        activeConfig[timer + 2] = 1;
        seal(); assert(!configValid(activeConfig, variant));
        testLoadStarterProfile(variant); testSetVariant(variant); testSetChordCount(1);
        uint8_t chord = configTimedOffset() - 3;
        activeConfig[chord] = 0;
        activeConfig[chord + 1] = CONFIG_ACTION_SCROLL | CONFIG_SCROLL_HOLD;
        activeConfig[chord + 2] = 1;
        seal(); assert(configValid(activeConfig, variant));
#if CONFIG_SCROLL_ACCELERATION
        testLoadStarterProfile(variant);
        for (uint8_t aux = 0; aux < 16; aux++) {
            activeConfig[9] = CONFIG_ACTION_SCROLL | (aux << 4);
            activeConfig[10] = 1;
            seal(); assert(!!configValid(activeConfig, variant) == (aux < 7 && (aux & 3) != 3));
            activeConfig[9] = activeConfig[10] = 0;
            activeConfig[rotation] = CONFIG_ACTION_SCROLL | (aux << 4);
            activeConfig[rotation + 1] = 1;
            seal(); assert(!!configValid(activeConfig, variant) == (aux < 3));
            activeConfig[rotation] = CONFIG_ACTION_SCROLL; activeConfig[rotation + 1] = 1;
        }
#endif
    }
}

static void testScrollAxisValidation(void) {
    for (uint8_t variant = 0; variant < 2; variant++) {
        for (uint8_t aux = 0; aux < 16; aux++) {
            for (uint8_t rotation = 0; rotation < 2; rotation++) {
                testLoadStarterProfile(variant);
                uint8_t offset = rotation ? 9 + 2 * ((variant ? 3 : 6) + 1) : 9;
                activeConfig[offset] = CONFIG_ACTION_SCROLL | (aux << 4);
                activeConfig[offset + 1] = 1;
                seal();
                assert(!!configValid(activeConfig, variant) == (!(aux & 3) && !(rotation && (aux & 4))));
            }
        }
        testLoadStarterProfile(variant);
        testSetTimedCount(1);
        uint8_t timer = configTimedOffset();
        activeConfig[timer + 1] = CONFIG_ACTION_SCROLL | CONFIG_SCROLL_HORIZONTAL;
        activeConfig[timer + 2] = -127;
        seal(); assert(configValid(activeConfig, variant));
        activeConfig[timer + 1] |= CONFIG_SCROLL_HOLD;
        seal(); assert(!configValid(activeConfig, variant));
        testLoadStarterProfile(variant); activeConfig[CONFIG_HEADER_VERSION] = 8;
        seal(); assert(!configValid(activeConfig, variant));
    }
}

static void testTypeZeroAndReserved(void) {
    for (uint8_t variant = 0; variant < 2; variant++) {
        // Key, rotation, chord, timer expiry/resume and unreferenced macro step.
        for (uint8_t slot = 0; slot < 6; slot++) {
            for (uint8_t aux = 0; aux < 16; aux++) {
                for (unsigned param = 0; param < 256; param++) {
                    testLoadStarterProfile(variant);
                    uint8_t offset = 9;
                    if (slot == 1) offset += 2 * (configKeyCount() + 1);
                    if (slot == 2) {
                        offset = configTimedOffset() + 1;
                        testSetChordCount(1);
                    }
                    if (slot == 3 || slot == 4) {
                        offset = configTimedOffset() + (slot == 3 ? 1 : 3);
                        testSetTimedCount(1);
                    }
                    uint8_t pool = configTimedOffset() + CONFIG_TIMED_SIZE * configTimedCount();
                    testSetStringLength(4);
                    memcpy(activeConfig + pool, "A\0B", 4);
                    if (slot == 5) offset = pool + 4;
                    activeConfig[offset] = (aux << 4) | CONFIG_ACTION_RESERVED;
                    activeConfig[offset + 1] = param;
                    seal(); assert(!configValid(activeConfig, variant));
                    // Raw type-0 bytes verify the new Pause-before-Text encoding.
                    // Macro zero terminators have a separate single-byte layout.
                    if (slot == 5) continue;
                    activeConfig[offset] = aux << 4;
                    seal(); assert(!!configValid(activeConfig, variant) ==
                        ((!aux) || (aux == 1 && CONFIG_MACRO_PAUSE) ||
                         (aux == 2 && (param == 0 || param == 2))));
                }
            }
        }
    }
}


static void testChordScopes(void) {
    // All raw identifiers, both geometries and every supported layer count.
    for (uint8_t variant = 0; variant < 2; variant++) {
        uint8_t maximum = variant ? 7 : 5;
        uint8_t size = variant ? 15 : 22;
        uint8_t pairs = variant ? 3 : 15;
        for (uint8_t layers = 1; layers <= maximum; layers++) {
            for (uint16_t id = 0; id < 256; id++) {
                testLoadStarterProfile(variant);
                testSetLayout(layers, 0, 0);
                testSetChordCount(1);
                uint8_t offset = 9 + size * layers;
                activeConfig[offset] = id;
                seal();
                uint8_t scope = id >> 4;
                uint8_t valid = (scope == 7 || scope < layers) && (id & 15) < pairs;
                assert(!!configValid(activeConfig, variant) == valid);
                if (valid) {
                    uint8_t first, second;
                    // Pair zero uses keys 0+1. Global scope applies on every layer.
                    if (!(id & 15)) for (uint8_t layer = 0; layer < layers; layer++) {
                        assert(!!configChord(layer, 0, 1, &first, &second) == (scope == 7 || scope == layer));
                    }
                }
            }
        }
    }
}

int main(void) {
    testChordScopes();
    testTypeZeroAndReserved();
    testConsumerHoldEncoding();
    testScrollHoldValidation();
    for (uint8_t variant = 0; variant < 2; variant++) {
        for (uint8_t timers = 0; timers < 8; timers++) {
            testLoadStarterProfile(variant);
            testSetLayout(1, 0, timers);
            testSetStringLength(0);
            seal();
            assert(configValid(activeConfig, variant) == (timers <= CONFIG_TIMED_MAX));
            if (timers <= CONFIG_TIMED_MAX) assert(configTimedCount() == timers);
        }
        testLoadStarterProfile(variant);
        uint8_t offset = configTimedOffset();
        testSetLayout(1, 0, 1);
        activeConfig[offset] = 255; // Longest interval, reset on input.
        activeConfig[offset + 1] = CONFIG_ACTION_STRING;
        activeConfig[offset + 2] = 0;
        testSetStringLength(2);
        activeConfig[offset + CONFIG_TIMED_SIZE] = 'A';
        activeConfig[offset + CONFIG_TIMED_SIZE + 1] = 0;
        seal();
        assert(configValid(activeConfig, variant)); // v7 bit 6 is consume, not interval.
        activeConfig[offset] = 128;
        seal();
        assert(configValid(activeConfig, variant));
        assert(configStringChar(0, 0) == 'A' && configStringChar(0, 1) == 0);
        for (uint8_t type = 0; type < 16; type++) {
            activeConfig[offset + 1] = type;
            activeConfig[offset + 2] = 0;
            if (type == CONFIG_ACTION_KEY_HOLD || type == CONFIG_ACTION_MOUSE_HOLD ||
                type == CONFIG_ACTION_MOMENTARY_LAYER) {
                seal();
                assert(!configValid(activeConfig, variant));
            }
        }
        testLoadStarterProfile(variant);
        activeConfig[CONFIG_HEADER_VERSION] = 6;
        testSetTimedCount(3); // Old reserved bits are not timer counts.
        seal();
        assert(!configValid(activeConfig, variant)); // Legacy requires host migration.
        testLoadStarterProfile(variant);
        activeConfig[CONFIG_HEADER_VERSION] = CONFIG_VERSION;
        testSetLayout(1, 0, 1);
        activeConfig[configTimedOffset()] = 255;
        seal();
        assert(configValid(activeConfig, variant) && configTimedCount() == 1);
        testLoadStarterProfile(variant);
        activeConfig[CONFIG_HEADER_VERSION] = CONFIG_VERSION;
        testSetStringLength(CONFIG_SIZE - (9 + (variant ? 15 : 22)));
        seal();
        assert(configValid(activeConfig, variant)); // Full string-pool budget.
        for (uint8_t version = CONFIG_VERSION + 1; version <= CONFIG_VERSION + 2; version++) {
            activeConfig[CONFIG_HEADER_VERSION] = version;
            seal();
            assert(!configValid(activeConfig, variant)); // Superseded local experiments.
        }
    }
    testPreviousLayerSentinel();
    testLedPayloads();
    testExpandedLayers(0);
    testExpandedLayers(1);
    testStarterFixture(CONFIG_SIX_KEYS);
    testStarterFixture(CONFIG_THREE_KEYS);
    testCachedColorOffsets(CONFIG_SIX_KEYS);
    testCachedColorOffsets(CONFIG_THREE_KEYS);
    testInvalid();
    testHeaderAndIgnoredFields();
    testCapacityAndStrings(CONFIG_SIX_KEYS);
    testCapacityAndStrings(CONFIG_THREE_KEYS);
    testStringBoundaries();
    testChords();
    testEveryChordPair();
    testPersistentMouseModes();
    testMouseButtonMasks();
    testMultiClick();
    testActions();
    testScrollAxisValidation();
    return 0;
}
